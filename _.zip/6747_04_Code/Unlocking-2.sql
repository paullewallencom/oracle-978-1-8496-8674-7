alter user hr identified by hr account unlock; #Unlock and open in a single statement

