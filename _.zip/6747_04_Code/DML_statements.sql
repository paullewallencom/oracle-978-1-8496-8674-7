-- Insert a record
INSERT INTO regions VALUES (5, 'Australia');

-- Update a record
UPDATE regions SET region_name = 'Aus and NZ' Where region_id = 5;

-- Delete a record
DELETE FROM regions Where region_id = 5;

