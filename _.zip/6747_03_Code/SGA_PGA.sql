ALTER SYSTEM SET sga_target=600m SCOPE=spfile;

ALTER SYSTEM SET pga_aggregate_target=400m SCOPE=spfile;
