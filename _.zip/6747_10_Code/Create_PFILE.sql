-- Create PFILE
CREATE pfile='c:\xe.ora' FROM spfile;