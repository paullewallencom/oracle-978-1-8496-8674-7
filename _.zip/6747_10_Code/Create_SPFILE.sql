-- Create SPFILE
CREATE spfile FROM pfile='c:\xe.ora';