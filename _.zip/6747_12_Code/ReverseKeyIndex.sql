-- Create reverse key index
SQL> CREATE INDEX emp_rki_idx ON emp(salary) REVERSE;
